"use strict";
(() => {
  // src/data/schema.ts
  var SITE_LABELS = {
    instagram: "Instagram",
    tiktok: "TikTok",
    twitter: "X / Twitter",
    reddit: "Reddit",
    youtube: "YouTube Shorts",
    facebook: "Facebook"
  };
  var DEFAULT_CONFIG = {
    cooldownMinutes: 20,
    retriggerEveryNScrolls: 30,
    doomThreshold: 0.6,
    minItemsForTrigger: 15,
    escalationIntensity: "normal",
    dailyBudgetMinutes: 60,
    weeklyBudgetMinutes: 0,
    perSiteEnabled: {
      instagram: true,
      tiktok: true,
      twitter: true,
      reddit: true,
      youtube: true,
      facebook: true
    },
    ifThenPlan: "",
    soundEnabled: true,
    aiEnabled: false,
    proxyUrl: ""
  };
  function clampCooldown(min) {
    return Math.max(15, Math.min(30, Math.round(min)));
  }
  var STORAGE_KEYS = {
    config: "si_config",
    cooldownPrefix: "si_cooldown_",
    digestCache: "si_digest_cache"
  };

  // src/background/storage.ts
  async function getConfig() {
    const raw = await chrome.storage.local.get(STORAGE_KEYS.config);
    const stored = raw[STORAGE_KEYS.config] ?? {};
    return {
      ...DEFAULT_CONFIG,
      ...stored,
      perSiteEnabled: { ...DEFAULT_CONFIG.perSiteEnabled, ...stored.perSiteEnabled ?? {} },
      cooldownMinutes: clampCooldown(stored.cooldownMinutes ?? DEFAULT_CONFIG.cooldownMinutes)
    };
  }

  // src/background/cooldown.ts
  var key = (site) => `${STORAGE_KEYS.cooldownPrefix}${site}`;
  var alarmName = (site) => `cooldown:${site}`;
  async function getCooldownUntil(site) {
    const raw = await chrome.storage.local.get(key(site));
    const until = raw[key(site)] ?? 0;
    return until > Date.now() ? until : 0;
  }
  async function startCooldown(site) {
    const cfg = await getConfig();
    const until = Date.now() + cfg.cooldownMinutes * 6e4;
    await chrome.storage.local.set({ [key(site)]: until });
    await chrome.alarms.create(alarmName(site), { when: until });
    return until;
  }
  async function clearCooldown(site) {
    await chrome.storage.local.remove(key(site));
  }
  function siteFromAlarm(name) {
    if (!name.startsWith("cooldown:")) return null;
    return name.slice("cooldown:".length);
  }
  async function rearmAlarms() {
    const all = await chrome.storage.local.get(null);
    for (const [k, v] of Object.entries(all)) {
      if (!k.startsWith(STORAGE_KEYS.cooldownPrefix)) continue;
      const site = k.slice(STORAGE_KEYS.cooldownPrefix.length);
      const until = v;
      if (until > Date.now()) {
        await chrome.alarms.create(alarmName(site), { when: until });
      } else {
        await chrome.storage.local.remove(k);
      }
    }
  }

  // src/data/eventLog.ts
  var DB_NAME = "finite_scroll";
  var STORE = "events";
  var DB_VERSION = 1;
  var RETENTION_MS = 90 * 24 * 60 * 60 * 1e3;
  var dbPromise = null;
  function openDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          const store = db.createObjectStore(STORE, { keyPath: "id", autoIncrement: true });
          store.createIndex("ts", "ts");
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }
  async function appendEvent(event) {
    const db = await openDB();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).add(event);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  async function getEventsSince(since) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const idx = tx.objectStore(STORE).index("ts");
      const range = IDBKeyRange.lowerBound(since);
      const out = [];
      idx.openCursor(range).onsuccess = (e) => {
        const cursor = e.target.result;
        if (cursor) {
          out.push(cursor.value);
          cursor.continue();
        } else {
          resolve(out);
        }
      };
      tx.onerror = () => reject(tx.error);
    });
  }
  async function pruneOld() {
    const db = await openDB();
    const cutoff = Date.now() - RETENTION_MS;
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      const idx = tx.objectStore(STORE).index("ts");
      idx.openCursor(IDBKeyRange.upperBound(cutoff)).onsuccess = (e) => {
        const cursor = e.target.result;
        if (cursor) {
          cursor.delete();
          cursor.continue();
        }
      };
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  // src/data/rollups.ts
  var DAY_MS = 24 * 60 * 60 * 1e3;
  function startOfDay(ts) {
    const d = new Date(ts);
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  }
  async function computeStats(now = Date.now()) {
    const weekStart = startOfDay(now) - 6 * DAY_MS;
    const events = await getEventsSince(weekStart);
    const todayStart = startOfDay(now);
    let todayMinutes = 0;
    let weekMinutes = 0;
    let todaySessions = 0;
    let bingeEpisodesToday = 0;
    let interventionsToday = 0;
    let respToday = 0;
    let acceptedToday = 0;
    const heatmap = Array.from({ length: 7 }, () => new Array(24).fill(0));
    const bingeDays = /* @__PURE__ */ new Set();
    for (const ev of events) {
      const isToday = ev.ts >= todayStart;
      if (ev.type === "session_end") {
        const mins = ev.durationMs / 6e4;
        weekMinutes += mins;
        if (isToday) {
          todayMinutes += mins;
          todaySessions += 1;
          if (ev.kind === "binge") bingeEpisodesToday += 1;
        }
        if (ev.kind === "binge") bingeDays.add(startOfDay(ev.ts));
        const dayIdx = Math.floor((startOfDay(ev.ts) - weekStart) / DAY_MS);
        const hour = new Date(ev.ts).getHours();
        if (dayIdx >= 0 && dayIdx < 7) heatmap[dayIdx][hour] += mins;
      } else if (ev.type === "intervention_shown" && isToday) {
        interventionsToday += 1;
      } else if (ev.type === "intervention_response" && isToday) {
        respToday += 1;
        if (ev.response === "accepted_break" || ev.response === "closed_feed") acceptedToday += 1;
      }
    }
    let currentStreakDays = 0;
    for (let i = 0; ; i++) {
      const day = startOfDay(now) - i * DAY_MS;
      if (bingeDays.has(day)) break;
      currentStreakDays += 1;
      if (i > 365) break;
    }
    return {
      todayMinutes: Math.round(todayMinutes),
      weekMinutes: Math.round(weekMinutes),
      todaySessions,
      bingeEpisodesToday,
      interventionsToday,
      acceptRate: respToday > 0 ? acceptedToday / respToday : 0,
      heatmap,
      currentStreakDays
    };
  }

  // src/data/patternDetector.ts
  var DAY_MS2 = 24 * 60 * 60 * 1e3;
  function startOfDay2(ts) {
    const d = new Date(ts);
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  }
  var isLateNight = (h) => h >= 23 || h < 5;
  function weekLabel(ts) {
    const d = new Date(startOfDay2(ts) - 6 * DAY_MS2);
    return d.toISOString().slice(0, 10);
  }
  function buildWeeklyProfile(events, config, now = Date.now()) {
    const thisWeekStart = startOfDay2(now) - 6 * DAY_MS2;
    const lastWeekStart = thisWeekStart - 7 * DAY_MS2;
    const thisWeek = events.filter((e) => e.ts >= thisWeekStart);
    const lastWeek = events.filter((e) => e.ts >= lastWeekStart && e.ts < thisWeekStart);
    const sessions = thisWeek.filter((e) => e.type === "session_end");
    const lastSessions = lastWeek.filter((e) => e.type === "session_end");
    const totalMin = sumMinutes(sessions);
    const lastMin = sumMinutes(lastSessions);
    const vsLastWeekPct = lastMin > 0 ? Math.round((totalMin - lastMin) / lastMin * 100) : 0;
    const bingeSessions = sessions.filter((s) => s.kind === "binge");
    const bingeMin = sumMinutes(bingeSessions);
    const longestBingeMin = Math.round(Math.max(0, ...bingeSessions.map((s) => s.durationMs / 6e4)));
    const hotspot = topHotspot(bingeSessions);
    const lateThis = lateNightMinutes(sessions);
    const lateLast = lateNightMinutes(lastSessions);
    const lateDelta = lateLast > 0 ? Math.round((lateThis - lateLast) / lateLast * 100) : lateThis > 0 ? 100 : 0;
    const responses = thisWeek.filter((e) => e.type === "intervention_response");
    const accepted = responses.filter((r) => r.response === "accepted_break" || r.response === "closed_feed");
    const acceptRate = responses.length > 0 ? round2(accepted.length / responses.length) : 0;
    const adherence = goalAdherence(sessions, config.dailyBudgetMinutes, now);
    const patterns = [];
    if (hotspot) patterns.push(hotspot);
    if (Math.abs(lateDelta) >= 10) patterns.push({ type: "trend", metric: "late_night_load", deltaPct: lateDelta });
    return {
      weekOf: weekLabel(now),
      goals: config.dailyBudgetMinutes ? [{ metric: "daily_scroll_minutes", target: config.dailyBudgetMinutes, adherence }] : [],
      totals: { scrollMinutes: Math.round(totalMin), sessions: sessions.length, vsLastWeekPct },
      streaks: {
        currentDays: currentStreak(sessions, now),
        longestDays: currentStreak(sessions, now),
        // aproximación para MVP
        relapsesThisWeek: thisWeek.filter((e) => e.type === "relapse").length
      },
      stateMix: {
        bingePct: totalMin > 0 ? round2(bingeMin / totalMin) : 0,
        bingeEpisodes: bingeSessions.length,
        longestBingeMin
      },
      patterns,
      interventionEfficacy: { best: "pausa_respiraci\xF3n", acceptRate },
      circadian: {
        interdailyStability: round2(interdailyStability(sessions)),
        lateNightLoadPct: totalMin > 0 ? round2(lateThis / totalMin) : 0
      }
    };
  }
  function sumMinutes(s) {
    return s.reduce((a, e) => a + e.durationMs / 6e4, 0);
  }
  function lateNightMinutes(s) {
    return s.filter((e) => isLateNight(new Date(e.ts).getHours())).reduce((a, e) => a + e.durationMs / 6e4, 0);
  }
  function round2(x) {
    return Math.round(x * 100) / 100;
  }
  function topHotspot(binge) {
    if (binge.length === 0) return null;
    const buckets = /* @__PURE__ */ new Map();
    for (const s of binge) {
      const h = new Date(s.ts).getHours();
      const window = `${pad(h)}:00-${pad((h + 2) % 24)}:00`;
      const k = `${s.site}|${window}`;
      const b = buckets.get(k) ?? { app: SITE_LABELS[s.site], window, min: 0, count: 0 };
      b.min += s.durationMs / 6e4;
      b.count += 1;
      buckets.set(k, b);
    }
    const top = [...buckets.values()].sort((a, b) => b.min - a.min)[0];
    const totalBinge = sumMinutes(binge);
    return {
      type: "hotspot",
      app: top.app,
      window: top.window,
      share: round2(top.min / totalBinge),
      bingeRate: round2(top.count / binge.length)
    };
  }
  function goalAdherence(sessions, budget, now) {
    if (!budget) return 1;
    const byDay = /* @__PURE__ */ new Map();
    for (const s of sessions) {
      const day = startOfDay2(s.ts);
      byDay.set(day, (byDay.get(day) ?? 0) + s.durationMs / 6e4);
    }
    let ok = 0;
    for (let i = 0; i < 7; i++) {
      const day = startOfDay2(now) - i * DAY_MS2;
      if ((byDay.get(day) ?? 0) <= budget) ok += 1;
    }
    return round2(ok / 7);
  }
  function currentStreak(sessions, now) {
    const bingeDays = new Set(sessions.filter((s) => s.kind === "binge").map((s) => startOfDay2(s.ts)));
    let streak = 0;
    for (let i = 0; i < 365; i++) {
      const day = startOfDay2(now) - i * DAY_MS2;
      if (bingeDays.has(day)) break;
      streak += 1;
    }
    return streak;
  }
  function interdailyStability(sessions) {
    const days = new Set(sessions.map((s) => startOfDay2(s.ts)));
    return Math.min(1, days.size / 7);
  }
  var pad = (n) => String(n).padStart(2, "0");
  function seededProfile() {
    return {
      weekOf: "2026-05-25",
      goals: [{ metric: "daily_scroll_minutes", target: 60, adherence: 0.57 }],
      totals: { scrollMinutes: 612, sessions: 143, vsLastWeekPct: -8 },
      streaks: { currentDays: 3, longestDays: 11, relapsesThisWeek: 2 },
      stateMix: { bingePct: 0.31, bingeEpisodes: 9, longestBingeMin: 74 },
      patterns: [
        { type: "hotspot", app: "TikTok", window: "23:00-01:00", share: 0.42, bingeRate: 0.7 },
        { type: "entry_trigger", source: "notificaci\xF3n push", bingeShare: 0.61 },
        { type: "trend", metric: "late_night_load", deltaPct: 15 }
      ],
      interventionEfficacy: { best: "pausa_respiraci\xF3n", acceptRate: 0.48 },
      circadian: { interdailyStability: 0.4, lateNightLoadPct: 0.34 }
    };
  }

  // src/background/aiProxyClient.ts
  var BANNED = ["adicci\xF3n", "adiccion", "adicto", "adicta", "trastorno", "fracaso", "fracasaste", "malo", "mala"];
  var DigestError = class extends Error {
  };
  async function fetchDigest(proxyUrl, profile) {
    if (!proxyUrl) throw new DigestError("No hay proxyUrl configurada (Opciones > Capa IA).");
    let resp;
    try {
      resp = await fetch(proxyUrl, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ profile })
      });
    } catch (e) {
      throw new DigestError(`No se pudo contactar el proxy: ${e.message}`);
    }
    if (!resp.ok) throw new DigestError(`Proxy respondi\xF3 ${resp.status}`);
    const data = await resp.json();
    const digest = validateDigest(data);
    return digest;
  }
  function validateDigest(data) {
    if (!data || typeof data !== "object") throw new DigestError("Respuesta no es un objeto.");
    const d = data;
    if (typeof d.celebration !== "string" || typeof d.insight !== "string" || typeof d.tone_check !== "string") {
      throw new DigestError("Faltan campos de texto en el digest.");
    }
    if (!Array.isArray(d.recommendations) || d.recommendations.length === 0) {
      throw new DigestError("El digest no trae recomendaciones.");
    }
    const recs = d.recommendations.map((r) => {
      const rr = r;
      if (typeof rr.title !== "string" || typeof rr.action !== "string" || typeof rr.why !== "string") {
        throw new DigestError("Recomendaci\xF3n con formato inv\xE1lido.");
      }
      return {
        title: rr.title,
        action: rr.action,
        why: rr.why,
        tied_to_pattern: typeof rr.tied_to_pattern === "string" ? rr.tied_to_pattern : ""
      };
    });
    const digest = {
      celebration: d.celebration,
      insight: d.insight,
      recommendations: recs,
      tone_check: d.tone_check
    };
    const blob = JSON.stringify(digest).toLowerCase();
    const hit = BANNED.find((w) => blob.includes(w));
    if (hit) throw new DigestError(`El digest us\xF3 una palabra prohibida ("${hit}"); se descart\xF3.`);
    return digest;
  }

  // src/background/serviceWorker.ts
  var PRUNE_ALARM = "prune:daily";
  var FOURTEEN_DAYS = 14 * 24 * 60 * 60 * 1e3;
  chrome.runtime.onInstalled.addListener(() => {
    void rearmAlarms();
    void chrome.alarms.create(PRUNE_ALARM, { periodInMinutes: 24 * 60 });
  });
  chrome.runtime.onStartup.addListener(() => {
    void rearmAlarms();
  });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === PRUNE_ALARM) {
      void pruneOld();
      return;
    }
    const site = siteFromAlarm(alarm.name);
    if (site) void clearCooldown(site);
  });
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    handle(msg).then(sendResponse).catch((e) => {
      console.debug("[Finite Scroll][bg] error", e);
      sendResponse({ kind: "OK" });
    });
    return true;
  });
  async function handle(msg) {
    switch (msg.kind) {
      case "GET_CONFIG":
        return { kind: "CONFIG", config: await getConfig() };
      case "LOG_EVENT":
        await appendEvent(msg.event);
        return { kind: "OK" };
      case "START_COOLDOWN":
        return { kind: "COOLDOWN", until: await startCooldown(msg.site) };
      case "GET_COOLDOWN":
        return { kind: "COOLDOWN", until: await getCooldownUntil(msg.site) };
      case "GET_STATS":
        return { kind: "STATS", stats: await computeStats() };
      case "GET_DIGEST":
        return getDigest();
    }
  }
  async function getDigest() {
    const config = await getConfig();
    try {
      const events = await getEventsSince(Date.now() - FOURTEEN_DAYS);
      const real = buildWeeklyProfile(events, config);
      const profile = real.totals.sessions >= 5 ? real : seededProfile();
      const digest = await fetchDigest(config.proxyUrl, profile);
      return { kind: "DIGEST", digest };
    } catch (e) {
      const msg = e instanceof DigestError ? e.message : e.message;
      return { kind: "DIGEST", digest: null, error: msg };
    }
  }
})();
//# sourceMappingURL=background.js.map
