"use strict";
(() => {
  // src/ui/uiClient.ts
  function send(msg) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(msg, (resp) => {
        const err = chrome.runtime.lastError;
        if (err) return reject(new Error(err.message));
        resolve(resp);
      });
    });
  }
  async function getStats() {
    const r = await send({ kind: "GET_STATS" });
    return r.stats;
  }
  async function getDigest() {
    const r = await send({ kind: "GET_DIGEST" });
    return { digest: r.digest, error: r.error };
  }

  // src/ui/popup.ts
  function $(id) {
    const el = document.getElementById(id);
    if (!el) throw new Error(`#${id} no existe`);
    return el;
  }
  function renderStats(s) {
    $("todayMin").textContent = String(s.todayMinutes);
    $("streak").textContent = String(s.currentStreakDays);
    $("sessions").textContent = String(s.todaySessions);
    $("binges").textContent = String(s.bingeEpisodesToday);
    $("interventions").textContent = String(s.interventionsToday);
    $("acceptRate").textContent = `${Math.round(s.acceptRate * 100)}%`;
    renderHeatmap(s.heatmap);
  }
  function renderHeatmap(heatmap) {
    const flat = heatmap.flat();
    const max = Math.max(1, ...flat);
    const host = $("heatmap");
    host.innerHTML = "";
    const today = heatmap[heatmap.length - 1] ?? new Array(24).fill(0);
    for (let h = 0; h < 24; h++) {
      const cell = document.createElement("div");
      cell.className = "cell";
      const v = today[h] / max;
      cell.style.background = v > 0 ? `rgba(108,92,231,${0.25 + v * 0.75})` : "#232a52";
      cell.title = `${String(h).padStart(2, "0")}:00 \u2014 ${Math.round(today[h])} min`;
      host.appendChild(cell);
    }
  }
  function renderDigest(digest) {
    const host = $("digest");
    host.innerHTML = "";
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
    <div class="celebration">\u{1F389} ${escape(digest.celebration)}</div>
    <div class="insight">${escape(digest.insight)}</div>
    ${digest.recommendations.map(
      (r) => `<div class="rec">
          <div class="t">${escape(r.title)}</div>
          <div class="a">\u2192 ${escape(r.action)}</div>
          <div class="w">${escape(r.why)}</div>
        </div>`
    ).join("")}
  `;
    host.appendChild(card);
  }
  function escape(s) {
    const d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
  }
  async function load() {
    try {
      renderStats(await getStats());
    } catch (e) {
      $("todayMin").textContent = "\u2013";
      console.debug(e);
    }
  }
  $("getDigest").addEventListener("click", async () => {
    const btn = $("getDigest");
    btn.disabled = true;
    btn.textContent = "\u23F3 Pensando\u2026";
    const host = $("digest");
    try {
      const { digest, error } = await getDigest();
      if (digest) {
        renderDigest(digest);
      } else {
        host.innerHTML = `<div class="card err">${escape(error ?? "No se pudo generar.")}<br><span class="muted">Configura el proxy en Opciones \u203A Capa IA.</span></div>`;
      }
    } catch (e) {
      host.innerHTML = `<div class="card err">${escape(e.message)}</div>`;
    } finally {
      btn.disabled = false;
      btn.textContent = "\u2728 Generar recomendaciones";
    }
  });
  $("testScreamer").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("demo.html") });
  });
  $("resetCounter").addEventListener("click", async () => {
    const btn = $("resetCounter");
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    chrome.tabs.sendMessage(tab.id, { kind: "RESET_COUNTER" }, () => {
      const err = chrome.runtime.lastError;
      btn.textContent = err ? "\u26A0\uFE0F Abre TikTok/IG/Shorts primero" : "\u2713 Contador reiniciado";
      setTimeout(() => btn.textContent = "\u{1F504} Reiniciar contador (en esta pesta\xF1a)", 1600);
    });
  });
  $("openOptions").addEventListener("click", () => chrome.runtime.openOptionsPage());
  void load();
})();
//# sourceMappingURL=popup.js.map
