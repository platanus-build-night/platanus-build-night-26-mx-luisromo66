"use strict";
(() => {
  // src/ui/popup.ts
  function $(id) {
    const el = document.getElementById(id);
    if (!el) throw new Error(`#${id} no existe`);
    return el;
  }
  $("openDashboard").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
  });
  $("testScreamer").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("demo.html") });
  });
  $("resetCounter").addEventListener("click", async () => {
    const btn = $("resetCounter");
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    chrome.tabs.sendMessage(tab.id, { kind: "RESET_COUNTER" }, () => {
      const err = chrome.runtime.lastError;
      btn.textContent = err ? "\u26A0\uFE0F Abre TikTok/IG/Shorts primero" : "\u2713 Contador reiniciado";
      setTimeout(() => btn.textContent = "\u{1F504} Reiniciar contador (en esta pesta\xF1a)", 1600);
    });
  });
  $("openOptions").addEventListener("click", () => chrome.runtime.openOptionsPage());
})();
//# sourceMappingURL=popup.js.map
