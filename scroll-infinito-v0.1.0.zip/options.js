"use strict";
(() => {
  // src/data/schema.ts
  var SITE_LABELS = {
    instagram: "Instagram",
    tiktok: "TikTok",
    twitter: "X / Twitter",
    reddit: "Reddit",
    youtube: "YouTube Shorts",
    facebook: "Facebook"
  };
  var DEFAULT_CONFIG = {
    cooldownMinutes: 20,
    retriggerEveryNScrolls: 30,
    doomThreshold: 0.6,
    minItemsForTrigger: 15,
    escalationIntensity: "normal",
    dailyBudgetMinutes: 60,
    weeklyBudgetMinutes: 0,
    perSiteEnabled: {
      instagram: true,
      tiktok: true,
      twitter: true,
      reddit: true,
      youtube: true,
      facebook: true
    },
    ifThenPlan: "",
    soundEnabled: true,
    aiEnabled: false,
    proxyUrl: ""
  };
  function clampCooldown(min) {
    return Math.max(15, Math.min(30, Math.round(min)));
  }
  var STORAGE_KEYS = {
    config: "si_config",
    cooldownPrefix: "si_cooldown_",
    digestCache: "si_digest_cache"
  };

  // src/background/storage.ts
  async function getConfig() {
    const raw = await chrome.storage.local.get(STORAGE_KEYS.config);
    const stored = raw[STORAGE_KEYS.config] ?? {};
    return {
      ...DEFAULT_CONFIG,
      ...stored,
      perSiteEnabled: { ...DEFAULT_CONFIG.perSiteEnabled, ...stored.perSiteEnabled ?? {} },
      cooldownMinutes: clampCooldown(stored.cooldownMinutes ?? DEFAULT_CONFIG.cooldownMinutes)
    };
  }
  async function setConfig(patch) {
    const current = await getConfig();
    const next = {
      ...current,
      ...patch,
      perSiteEnabled: { ...current.perSiteEnabled, ...patch.perSiteEnabled ?? {} },
      cooldownMinutes: clampCooldown(patch.cooldownMinutes ?? current.cooldownMinutes)
    };
    await chrome.storage.local.set({ [STORAGE_KEYS.config]: next });
    return next;
  }

  // src/data/eventLog.ts
  var DB_NAME = "scroll_infinito";
  var STORE = "events";
  var DB_VERSION = 1;
  var RETENTION_MS = 90 * 24 * 60 * 60 * 1e3;
  var dbPromise = null;
  function openDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          const store = db.createObjectStore(STORE, { keyPath: "id", autoIncrement: true });
          store.createIndex("ts", "ts");
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }
  async function clearAll() {
    const db = await openDB();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  // src/ui/options.ts
  function el(id) {
    const e = document.getElementById(id);
    if (!e) throw new Error(`#${id} no existe`);
    return e;
  }
  var SITE_IDS = Object.keys(SITE_LABELS);
  function renderSites(cfg) {
    const host = el("sites");
    host.innerHTML = "";
    for (const id of SITE_IDS) {
      const wrap = document.createElement("label");
      wrap.className = "site";
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = cfg.perSiteEnabled[id];
      cb.dataset.site = id;
      wrap.appendChild(cb);
      wrap.appendChild(document.createTextNode(SITE_LABELS[id]));
      host.appendChild(wrap);
    }
  }
  function fill(cfg) {
    el("cooldownMinutes").value = String(cfg.cooldownMinutes);
    el("cooldownVal").textContent = String(cfg.cooldownMinutes);
    el("retriggerEveryNScrolls").value = String(cfg.retriggerEveryNScrolls);
    el("escalationIntensity").value = cfg.escalationIntensity;
    el("soundEnabled").checked = cfg.soundEnabled;
    el("doomThreshold").value = String(cfg.doomThreshold);
    el("minItemsForTrigger").value = String(cfg.minItemsForTrigger);
    el("dailyBudgetMinutes").value = String(cfg.dailyBudgetMinutes);
    el("ifThenPlan").value = cfg.ifThenPlan;
    el("aiEnabled").checked = cfg.aiEnabled;
    el("proxyUrl").value = cfg.proxyUrl;
    renderSites(cfg);
  }
  function collect() {
    const perSiteEnabled = {};
    el("sites").querySelectorAll('input[type="checkbox"]').forEach((cb) => {
      perSiteEnabled[cb.dataset.site] = cb.checked;
    });
    return {
      cooldownMinutes: Number(el("cooldownMinutes").value),
      retriggerEveryNScrolls: Number(el("retriggerEveryNScrolls").value),
      escalationIntensity: el("escalationIntensity").value,
      soundEnabled: el("soundEnabled").checked,
      doomThreshold: Number(el("doomThreshold").value),
      minItemsForTrigger: Number(el("minItemsForTrigger").value),
      dailyBudgetMinutes: Number(el("dailyBudgetMinutes").value),
      ifThenPlan: el("ifThenPlan").value.trim(),
      aiEnabled: el("aiEnabled").checked,
      proxyUrl: el("proxyUrl").value.trim(),
      perSiteEnabled
    };
  }
  el("cooldownMinutes").addEventListener("input", (e) => {
    el("cooldownVal").textContent = e.target.value;
  });
  el("save").addEventListener("click", async () => {
    await setConfig(collect());
    const saved = el("saved");
    saved.classList.add("show");
    setTimeout(() => saved.classList.remove("show"), 1500);
  });
  el("clearData").addEventListener("click", async () => {
    if (!confirm("\xBFBorrar todos tus datos de scroll? Esto no se puede deshacer.")) return;
    await clearAll();
    alert("Listo, datos borrados.");
  });
  void (async () => fill(await getConfig()))();
})();
//# sourceMappingURL=options.js.map
