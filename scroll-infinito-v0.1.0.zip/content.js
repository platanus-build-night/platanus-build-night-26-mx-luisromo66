"use strict";
(() => {
  // src/content/siteAdapters.ts
  var ADAPTERS = [
    {
      id: "instagram",
      matchHost: (h) => h.endsWith("instagram.com"),
      // Home feed "/" y reels "/reels/...". Excluye posts aislados "/p/..." y perfiles.
      isFeedPath: (p) => p === "/" || p.startsWith("/reels"),
      feedContainerSelectors: ['main[role="main"]', "section main"],
      itemSelector: "article"
    },
    {
      id: "tiktok",
      matchHost: (h) => h.endsWith("tiktok.com"),
      isFeedPath: (p) => p === "/" || p.startsWith("/foryou") || p.startsWith("/following"),
      feedContainerSelectors: ['[data-e2e="recommend-list-item-container"]', "#main-content-homepage_hot", "main"],
      itemSelector: '[data-e2e="recommend-list-item-container"], article'
    },
    {
      id: "twitter",
      matchHost: (h) => h.endsWith("twitter.com") || h.endsWith("x.com"),
      isFeedPath: (p) => p === "/home" || p === "/" || p.startsWith("/i/timeline"),
      feedContainerSelectors: ['[aria-label][role="region"]', 'main[role="main"]'],
      itemSelector: 'article[data-testid="tweet"], article'
    },
    {
      id: "reddit",
      matchHost: (h) => h.endsWith("reddit.com"),
      // Listings (home, popular, subreddits) pero NO páginas de comentarios.
      isFeedPath: (p) => !p.includes("/comments/") && (p === "/" || p.startsWith("/r/") || p.startsWith("/best") || p.startsWith("/hot") || p.startsWith("/new") || p.startsWith("/top")),
      feedContainerSelectors: ["shreddit-feed", '[data-testid="post-container"]', "main"],
      itemSelector: 'shreddit-post, article, [data-testid="post-container"]'
    },
    {
      id: "youtube",
      matchHost: (h) => h.endsWith("youtube.com"),
      // Solo Shorts (scroll infinito). El home no es scroll-infinito clásico.
      isFeedPath: (p) => p.startsWith("/shorts"),
      feedContainerSelectors: ["#shorts-container", "ytd-reel-video-renderer", "ytd-shorts"],
      itemSelector: "ytd-reel-video-renderer"
    },
    {
      id: "facebook",
      matchHost: (h) => h.endsWith("facebook.com"),
      isFeedPath: (p) => p === "/" || p.startsWith("/reel") || p.startsWith("/watch"),
      feedContainerSelectors: ['[role="feed"]', '[role="main"]'],
      itemSelector: '[role="article"]'
    }
  ];
  function getAdapterForHost(host) {
    return ADAPTERS.find((a) => a.matchHost(host)) ?? null;
  }
  function resolveFeedContainer(adapter) {
    for (const sel of adapter.feedContainerSelectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  // src/content/scrollSensor.ts
  var ScrollSensor = class {
    constructor(throttleMs = 200) {
      this.lastY = window.scrollY;
      this.lastT = performance.now();
      this.velocities = [];
      this.pending = false;
      this.totalDistance = 0;
      this.scrollCount = 0;
      this.handleWheel = () => this.handle();
      this.handle = () => {
        if (this.pending) return;
        this.pending = true;
        setTimeout(() => {
          this.pending = false;
          this.process();
        }, this.throttleMs);
      };
      this.throttleMs = throttleMs;
    }
    start() {
      window.addEventListener("scroll", this.handle, { passive: true });
      window.addEventListener("wheel", this.handleWheel, { passive: true });
      document.addEventListener("scroll", this.handle, { passive: true, capture: true });
      window.addEventListener("touchmove", this.handleWheel, { passive: true });
    }
    stop() {
      window.removeEventListener("scroll", this.handle);
      window.removeEventListener("wheel", this.handleWheel);
      document.removeEventListener("scroll", this.handle, { capture: true });
      window.removeEventListener("touchmove", this.handleWheel);
    }
    /** Tick sintético: avance de Short por cambio de URL (cuenta como una pantalla). */
    pump(screens = 1) {
      this.registerTick(window.innerHeight * screens, 6e3);
    }
    reset() {
      this.totalDistance = 0;
      this.scrollCount = 0;
      this.velocities = [];
      this.lastY = window.scrollY;
      this.lastT = performance.now();
    }
    /** Velocidad p95 (px/s) sobre las últimas muestras. */
    p95Velocity() {
      if (this.velocities.length === 0) return 0;
      const sorted = [...this.velocities].sort((a, b) => a - b);
      const idx = Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95));
      return sorted[idx];
    }
    process() {
      const now = performance.now();
      const y = window.scrollY;
      const dy = Math.abs(y - this.lastY);
      const dt = (now - this.lastT) / 1e3;
      if (dy < 1) {
        this.registerTick(window.innerHeight * 0.9, dt > 0 ? window.innerHeight * 0.9 / dt : 0);
      } else {
        const velocity = dt > 0 ? dy / dt : 0;
        this.registerTick(dy, velocity);
      }
      this.lastY = y;
      this.lastT = now;
    }
    registerTick(dy, velocity) {
      this.totalDistance += dy;
      this.scrollCount += 1;
      this.velocities.push(velocity);
      if (this.velocities.length > 100) this.velocities.shift();
      this.onTick?.({ dy, velocity, scrollCount: this.scrollCount });
    }
  };

  // src/content/feedObserver.ts
  var FeedObserver = class {
    constructor(adapter) {
      this.dwellStart = /* @__PURE__ */ new Map();
      this.itemsAppended = 0;
      this.dwellSamples = [];
      this.adapter = adapter;
    }
    start() {
      const container = resolveFeedContainer(this.adapter) ?? document.body;
      this.mutation = new MutationObserver((mutations) => {
        let added = 0;
        for (const m of mutations) {
          m.addedNodes.forEach((n) => {
            if (n.nodeType !== Node.ELEMENT_NODE) return;
            const el = n;
            if (el.matches?.(this.adapter.itemSelector) || el.querySelector?.(this.adapter.itemSelector)) {
              added += 1;
              this.observeItem(el);
            }
          });
        }
        if (added > 0) {
          this.itemsAppended += added;
          this.onItemsAppended?.(added);
        }
      });
      this.mutation.observe(container, { childList: true, subtree: true });
      this.intersection = new IntersectionObserver(
        (entries) => {
          const now = performance.now();
          for (const e of entries) {
            if (e.isIntersecting) {
              this.dwellStart.set(e.target, now);
            } else {
              const start = this.dwellStart.get(e.target);
              if (start != null) {
                this.dwellSamples.push(now - start);
                if (this.dwellSamples.length > 100) this.dwellSamples.shift();
                this.dwellStart.delete(e.target);
              }
            }
          }
        },
        { threshold: 0.5 }
      );
      document.querySelectorAll(this.adapter.itemSelector).forEach((el) => this.observeItem(el));
    }
    observeItem(el) {
      try {
        this.intersection?.observe(el);
      } catch {
      }
    }
    /** Suma items manualmente (p.ej. avance de Short por cambio de URL). */
    bumpItems(n = 1) {
      this.itemsAppended += n;
    }
    /** Fracción de impresiones con dwell bajo (<1.2s) = flicking de baja atención [0,1]. */
    lowDwellRatio() {
      if (this.dwellSamples.length === 0) return 0;
      const low = this.dwellSamples.filter((d) => d < 1200).length;
      return low / this.dwellSamples.length;
    }
    reset() {
      this.itemsAppended = 0;
      this.dwellSamples = [];
      this.dwellStart.clear();
    }
    stop() {
      this.mutation?.disconnect();
      this.intersection?.disconnect();
      this.dwellStart.clear();
    }
  };

  // src/content/doomScore.ts
  var DOOM_TERMS = {
    activeFeedSec: { soft: 20, hard: 180, weight: 0.3 },
    // 20s..3min
    screens: { soft: 3, hard: 25, weight: 0.25 },
    // pantallas scrolleadas
    p95Velocity: { soft: 800, hard: 6e3, weight: 0.2 },
    // px/s
    items: { soft: 5, hard: 40, weight: 0.15 },
    lowDwell: { soft: 0.2, hard: 0.8, weight: 0.1 }
  };
  function norm(x, t) {
    if (t.hard === t.soft) return x >= t.hard ? 1 : 0;
    return Math.max(0, Math.min(1, (x - t.soft) / (t.hard - t.soft)));
  }
  function computeDoomScore(s) {
    const screens = s.scrollDistancePx / Math.max(1, window.innerHeight);
    const terms = {
      activeFeed: norm(s.activeFeedMs / 1e3, DOOM_TERMS.activeFeedSec) * DOOM_TERMS.activeFeedSec.weight,
      screens: norm(screens, DOOM_TERMS.screens) * DOOM_TERMS.screens.weight,
      velocity: norm(s.p95Velocity, DOOM_TERMS.p95Velocity) * DOOM_TERMS.p95Velocity.weight,
      items: norm(s.itemsAppended, DOOM_TERMS.items) * DOOM_TERMS.items.weight,
      lowDwell: norm(s.lowDwellRatio, DOOM_TERMS.lowDwell) * DOOM_TERMS.lowDwell.weight
    };
    const score = Object.values(terms).reduce((a, b) => a + b, 0);
    return { score: Math.min(1, score), breakdown: terms, screens };
  }

  // src/content/bgClient.ts
  function send(msg) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(msg, (resp) => {
        const err = chrome.runtime.lastError;
        if (err) return reject(new Error(err.message));
        resolve(resp);
      });
    });
  }
  async function getConfig() {
    const r = await send({ kind: "GET_CONFIG" });
    return r.config;
  }
  function logEvent(event) {
    try {
      chrome.runtime.sendMessage({ kind: "LOG_EVENT", event }, () => void chrome.runtime.lastError);
    } catch {
    }
  }
  async function getTodayMinutes() {
    const r = await send({ kind: "GET_STATS" });
    return r.stats.todayMinutes;
  }

  // src/content/stateMachine.ts
  var MAX_LEVEL = 4;
  var StateMachine = class {
    constructor(d) {
      this.state = "WATCHING";
      this.sessionId = newId();
      this.episodeStart = Date.now();
      this.level = 0;
      this.scrollsAtLastTrigger = 0;
      this.interrupting = false;
      // Cooldown por INACTIVIDAD: el reset solo ocurre si dejas de scrollear 15-30 min.
      this.lastActivityTs = Date.now();
      this.lastScrollCount = 0;
      this.d = d;
    }
    async start() {
      this.lastActivityTs = Date.now();
      logEvent({
        type: "session_start",
        ts: Date.now(),
        site: this.d.adapter.id,
        sessionId: this.sessionId,
        entrySource: document.referrer ? "referral" : "direct"
      });
      this.d.sensor.start();
      this.d.observer.start();
      this.tickHandle = window.setInterval(() => this.tick(), 1e3);
    }
    stop() {
      if (this.tickHandle) clearInterval(this.tickHandle);
      this.d.sensor.stop();
      this.d.observer.stop();
      this.endSession("unload");
    }
    /** Llamado en cada cambio de ruta SPA. */
    onRouteChange(stillFeed) {
      if (!stillFeed && this.state !== "COOLDOWN") {
        this.goodExit("closed_feed");
      }
    }
    /** Tab oculto por un rato = buen exit. */
    onHidden() {
      if (this.state === "INTERRUPT") return;
      if (this.state !== "COOLDOWN") this.goodExit("closed_feed");
    }
    /** Reinicia el contador (scrolls, items, nivel) al instante. Útil para pruebas. */
    reset() {
      this.d.overlay.hide();
      this.resetEpisode();
      this.state = "WATCHING";
      console.log("[SCROLL_INFINITO] contador reiniciado a mano (scrolls/items/nivel = 0)");
    }
    /** Dispara el screamer a mano (atajo de teclado / consola). Útil para demo. */
    async forceInterrupt() {
      if (this.interrupting) return;
      const { score, screens } = this.currentScore();
      console.log("[SCROLL_INFINITO] disparo manual del screamer");
      await this.fireInterrupt("first", Math.max(score, this.d.config.doomThreshold), screens);
    }
    currentScore() {
      return computeDoomScore({
        activeFeedMs: Date.now() - this.episodeStart,
        scrollDistancePx: this.d.sensor.totalDistance,
        p95Velocity: this.d.sensor.p95Velocity(),
        itemsAppended: this.d.observer.itemsAppended,
        lowDwellRatio: this.d.observer.lowDwellRatio()
      });
    }
    async tick() {
      if (this.interrupting) return;
      if (!this.d.isFeedActive()) return;
      const { score, screens } = this.currentScore();
      const cfg = this.d.config;
      const scrolls = this.d.sensor.scrollCount;
      const now = Date.now();
      if (scrolls > this.lastScrollCount) this.lastActivityTs = now;
      this.lastScrollCount = scrolls;
      const idleMs = now - this.lastActivityTs;
      const cooldownMs = cfg.cooldownMinutes * 6e4;
      if (this.level > 0 && idleMs >= cooldownMs) {
        console.log("[SCROLL_INFINITO] inactividad alcanzada -> reset (reinicia todo)");
        this.resetEpisode();
        this.state = "COOLDOWN";
        return;
      }
      if (this.state === "COOLDOWN" && idleMs < cooldownMs) this.state = "WATCHING";
      if (score > 0.05 || scrolls > 0) {
        console.log(
          `[SCROLL_INFINITO] score=${score.toFixed(2)} items=${this.d.observer.itemsAppended} scrolls=${scrolls} idle=${Math.round(idleMs / 1e3)}s state=${this.state} L=${this.level}`
        );
      }
      const enoughEvidence = this.d.observer.itemsAppended >= cfg.minItemsForTrigger || scrolls >= cfg.minItemsForTrigger * 2;
      const firstTrigger = this.level === 0 && score >= cfg.doomThreshold && enoughEvidence;
      const reTrigger = this.level > 0 && scrolls - this.scrollsAtLastTrigger >= cfg.retriggerEveryNScrolls;
      if (firstTrigger || reTrigger) {
        this.scrollsAtLastTrigger = scrolls;
        await this.fireInterrupt(firstTrigger ? "first" : "retrigger", score, screens);
      }
    }
    async fireInterrupt(rule, score, screens) {
      this.interrupting = true;
      this.state = "INTERRUPT";
      this.level = Math.min(MAX_LEVEL, this.level + 1);
      logEvent({
        type: "intervention_shown",
        ts: Date.now(),
        site: this.d.adapter.id,
        sessionId: this.sessionId,
        rule,
        level: this.level,
        doomScore: Number(score.toFixed(3))
      });
      const shownAt = Date.now();
      let response = "ignored";
      try {
        response = await this.d.overlay.show({
          level: this.level,
          screens: Math.round(screens),
          budgetUsedMin: this.d.getTodayMinutes?.(),
          budgetMin: this.d.config.dailyBudgetMinutes || void 0,
          soundEnabled: this.d.config.soundEnabled
        });
      } catch (e) {
        console.log("[SCROLL_INFINITO] error al mostrar el screamer:", e);
      } finally {
        this.interrupting = false;
        this.state = "WATCHING";
      }
      logEvent({
        type: "intervention_response",
        ts: Date.now(),
        site: this.d.adapter.id,
        sessionId: this.sessionId,
        response,
        level: this.level,
        latencyMs: Date.now() - shownAt
      });
      if (response === "accepted_break") {
        this.lastActivityTs = Date.now();
      }
    }
    /** Salida del feed (cambio de ruta / tab oculto): reinicia el episodio. */
    goodExit(reason) {
      this.d.overlay.hide();
      this.endSession(reason === "closed_feed" ? "left_feed" : "idle");
      this.resetEpisode();
      this.state = "WATCHING";
    }
    resetEpisode() {
      this.d.sensor.reset();
      this.d.observer.reset();
      this.episodeStart = Date.now();
      this.level = 0;
      this.scrollsAtLastTrigger = 0;
      this.lastScrollCount = 0;
      this.lastActivityTs = Date.now();
      this.sessionId = newId();
    }
    endSession(endReason) {
      const durationMs = Date.now() - this.episodeStart;
      const itemsSeen = this.d.observer.itemsAppended;
      const { score } = this.currentScore();
      const kind = score >= 0.6 ? "binge" : score >= 0.2 ? "passive_browse" : "quick_check";
      logEvent({
        type: "session_end",
        ts: Date.now(),
        site: this.d.adapter.id,
        sessionId: this.sessionId,
        endReason,
        kind,
        durationMs,
        scrollPx: this.d.sensor.totalDistance,
        itemsSeen
      });
    }
  };
  function newId() {
    return `${Date.now().toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`;
  }

  // src/content/overlay/levels.ts
  var BASE = [
    {
      level: 1,
      frictionSec: 0,
      emojiSize: 4,
      emojis: ["\u{1F440}"],
      title: "\xBFSigues ah\xED?",
      subtitlePool: [
        "Llevas ~{screens} pantallas. Respira una vez \u{1FAE7}",
        "Peque\xF1a pausa: \xBFesto te sirve ahora mismo?",
        "Hey, solo un check r\xE1pido \u{1F44B}"
      ],
      showUsageMirror: false,
      holdToContinue: false
    },
    {
      level: 2,
      frictionSec: 3,
      emojiSize: 7,
      emojis: ["\u{1F57A}", "\u{1F483}", "\u{1FAA9}", "\u{1F389}"],
      title: "OK esto ya es mucho scroll",
      subtitlePool: [
        "Tu pulgar entren\xF3 para un marat\xF3n \u{1F3C3}",
        "~{screens} pantallas. El algoritmo est\xE1 feliz, \xBFy t\xFA?",
        "Baile de interrupci\xF3n activado \u{1FAA9}"
      ],
      showUsageMirror: false,
      holdToContinue: false
    },
    {
      level: 3,
      frictionSec: 6,
      emojiSize: 10,
      emojis: ["\u{1F999}", "\u{1F6F8}", "\u{1F921}", "\u{1F438}"],
      title: "\xBFDe verdad quieres esto ahora?",
      subtitlePool: [
        'No "\xBFpuedo seguir?", sino: \xBFde verdad lo quiero? \u{1F914}',
        "Una llama te est\xE1 juzgando con cari\xF1o \u{1F999}",
        "Cierra los ojos 3 segundos. Te esperamos."
      ],
      showUsageMirror: true,
      holdToContinue: false
    },
    {
      level: 4,
      frictionSec: 8,
      emojiSize: 14,
      emojis: ["\u{1F6A8}", "\u{1F920}", "\u{1F996}", "\u{1FAE0}"],
      title: "SCROLL_INFINITO dice: ya estuvo \u{1F920}",
      subtitlePool: [
        "Mira tu d\xEDa. Mant\xE9n presionado si DE VERDAD quieres seguir.",
        "Tu yo de ma\xF1ana te lo va a agradecer \u{1FAE0}",
        "Plan twist: cierra esto y ve por agua \u{1F4A7}"
      ],
      showUsageMirror: true,
      holdToContinue: true
    }
  ];
  var INTENSITY_MULT = {
    suave: 0.5,
    normal: 1,
    intenso: 1.6
  };
  function getLevelSpec(level, intensity) {
    const spec = BASE[Math.max(0, Math.min(BASE.length - 1, level - 1))];
    return { ...spec, frictionSec: Math.round(spec.frictionSec * INTENSITY_MULT[intensity]) };
  }
  function pickSubtitle(spec, screens) {
    const idx = (spec.level + screens) % spec.subtitlePool.length;
    return spec.subtitlePool[idx].replace("{screens}", String(screens));
  }

  // src/content/overlay/a11y.ts
  function prefersReducedMotion() {
    return window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
  }

  // src/content/overlay/audioUnlock.ts
  var audio = null;
  var primed = false;
  function initScreamerAudio(url) {
    if (audio) return;
    audio = new Audio(url);
    audio.loop = true;
    audio.preload = "auto";
    const prime = () => {
      if (!audio || primed) return;
      audio.muted = false;
      audio.volume = 0;
      audio.play().then(() => {
        audio.pause();
        audio.currentTime = 0;
        primed = true;
        console.log("[SCROLL_INFINITO] audio desbloqueado para esta sesi\xF3n \u{1F50A}");
      }).catch(() => {
      });
    };
    ["pointerdown", "keydown", "touchstart"].forEach(
      (ev) => window.addEventListener(ev, prime, { capture: true, once: true })
    );
  }
  function playScreamerSound() {
    if (!audio) return Promise.reject(new Error("audio no inicializado"));
    audio.muted = false;
    audio.volume = 1;
    audio.currentTime = 0;
    return audio.play();
  }
  function primeNow() {
    if (!audio) return Promise.reject(new Error("audio no inicializado"));
    audio.muted = false;
    audio.volume = 0;
    return audio.play().then(() => {
      audio.pause();
      audio.currentTime = 0;
      audio.volume = 1;
      primed = true;
      console.log("[SCROLL_INFINITO] audio desbloqueado (clic expl\xEDcito) \u{1F50A}");
    });
  }
  function stopScreamerSound() {
    if (audio) {
      audio.pause();
      audio.currentTime = 0;
    }
  }
  function isAudioPrimed() {
    return primed;
  }

  // src/content/overlay/overlayHost.ts
  var HOST_ID = "scroll-infinito-overlay-host";
  var ScreamerOverlay = class {
    constructor(cfg) {
      this.timers = [];
      this.pausedMedia = [];
      this.cfg = cfg;
      try {
        initScreamerAudio(chrome.runtime.getURL("assets/screamer.mp4"));
      } catch {
      }
    }
    show(opts) {
      this.hide();
      this.pausePageMedia();
      return new Promise((resolve) => {
        this.resolveCurrent = resolve;
        this.render(opts);
      });
    }
    hide() {
      this.clearTimers();
      stopScreamerSound();
      this.host?.remove();
      this.host = void 0;
      this.resolveCurrent = void 0;
      this.resumePageMedia();
    }
    /** Pausa todo video/audio que esté sonando en la página (el Short de fondo). */
    pausePageMedia() {
      this.pausedMedia = [];
      document.querySelectorAll("video, audio").forEach((m) => {
        if (!m.paused && !m.ended) {
          try {
            m.pause();
            this.pausedMedia.push(m);
          } catch {
          }
        }
      });
    }
    /** Reanuda lo que pausamos cuando se cierra el screamer. */
    resumePageMedia() {
      this.pausedMedia.forEach((m) => void m.play().catch(() => {
      }));
      this.pausedMedia = [];
    }
    finish(r) {
      const resolve = this.resolveCurrent;
      this.hide();
      resolve?.(r);
    }
    clearTimers() {
      this.timers.forEach((t) => clearTimeout(t));
      this.timers = [];
    }
    render(opts) {
      const reduced = prefersReducedMotion();
      const spec = getLevelSpec(opts.level, this.cfg.escalationIntensity);
      const subtitle = pickSubtitle(spec, opts.screens);
      const host = document.createElement("div");
      host.id = HOST_ID;
      host.style.cssText = "all: initial; position: fixed; inset: 0; z-index: 2147483647;";
      const root = host.attachShadow({ mode: "open" });
      this.host = host;
      const videoUrl = chrome.runtime.getURL("assets/screamer.mp4");
      const mirror = spec.showUsageMirror && opts.budgetMin ? `<div class="mirror">Hoy: <b>${opts.budgetUsedMin ?? 0} min</b> / meta ${opts.budgetMin} min</div>` : spec.showUsageMirror && opts.budgetUsedMin ? `<div class="mirror">Hoy llevas <b>${opts.budgetUsedMin} min</b> de scroll</div>` : "";
      const videoMax = 220 + opts.level * 60;
      const template = `
      <style>
        :host { all: initial; }
        .backdrop {
          position: fixed; inset: 0;
          display: flex; align-items: center; justify-content: center;
          background: rgba(8, 10, 20, ${0.55 + opts.level * 0.1});
          backdrop-filter: blur(${2 + opts.level * 2}px);
          font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
          color: #fff; text-align: center; padding: 24px;
          ${reduced ? "" : "animation: si-fade 0.25s ease-out;"}
        }
        .card {
          max-width: 520px; width: 100%;
          background: linear-gradient(160deg, #1b2240, #2a1f4d);
          border: 2px solid #6c5ce7; border-radius: 22px;
          padding: 28px 26px 22px; box-shadow: 0 20px 60px rgba(0,0,0,.5);
        }
        .video-wrap { position: relative; display:flex; justify-content:center; }
        video.screamer {
          width: 100%; max-width: ${videoMax}px; border-radius: 16px;
          background: #000; box-shadow: 0 10px 30px rgba(0,0,0,.5);
        }
        .sound-btn {
          position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%);
          background: #e17055; color: #fff; font-weight: 700; font-size: .9rem;
          border: 0; border-radius: 999px; padding: 8px 16px; cursor: pointer;
          box-shadow: 0 4px 14px rgba(0,0,0,.4); animation: si-pulse 1.2s ease-in-out infinite;
        }
        @keyframes si-pulse { 0%,100% { transform: translateX(-50%) scale(1) } 50% { transform: translateX(-50%) scale(1.07) } }
        h1 { font-size: 1.55rem; margin: 14px 0 6px; }
        p.sub { font-size: 1.05rem; opacity: .9; margin: 0 0 14px; }
        .mirror { font-size: .95rem; background: rgba(255,255,255,.08); border-radius: 10px; padding: 8px 12px; margin: 0 0 16px; }
        .btns { display: flex; flex-direction: column; gap: 10px; }
        button { font: inherit; font-size: 1rem; padding: 13px 16px; border-radius: 12px; border: 0; cursor: pointer; }
        .primary { background: #00b894; color: #04241c; font-weight: 700; }
        .primary:hover { filter: brightness(1.08); }
        .secondary { background: rgba(255,255,255,.1); color: #fff; }
        .secondary[disabled] { opacity: .45; cursor: not-allowed; }
        .hold { background: rgba(255,255,255,.1); color:#fff; position:relative; overflow:hidden; }
        .hold .fill { position:absolute; inset:0; background:#e17055; width:0%; }
        .hold span { position: relative; z-index: 1; }
        .foot { margin-top: 12px; font-size: .8rem; opacity: .6; }
        @keyframes si-bounce { from { transform: translateY(0) } to { transform: translateY(-18px) } }
        @keyframes si-spin { to { transform: rotate(360deg) } }
        @keyframes si-fade { from { opacity: 0 } to { opacity: 1 } }
      </style>
      <div class="backdrop" role="dialog" aria-modal="true" aria-label="Pausa de scroll">
        <div class="card">
          <div class="video-wrap">
            <video class="screamer" src="${videoUrl}" loop playsinline></video>
            <button class="sound-btn" data-act="unmute" style="display:none">\u{1F50A} toca para sonido</button>
          </div>
          <h1>${spec.title}</h1>
          <p class="sub">${escapeHtml(subtitle)}</p>
          ${mirror}
          <div class="btns">
            <button class="primary" data-act="break">\u270B Ya termin\xE9 / tomar pausa</button>
            ${spec.holdToContinue ? `<button class="hold" data-act="hold"><span class="lbl">Mant\xE9n presionado para seguir\u2026</span><div class="fill"></div></button>` : `<button class="secondary" data-act="continue" ${spec.frictionSec > 0 ? "disabled" : ""}>Seguir scrolleando${spec.frictionSec > 0 ? ` (${spec.frictionSec})` : ""}</button>`}
          </div>
          <div class="foot">SCROLL_INFINITO \xB7 nivel ${opts.level}</div>
        </div>
      </div>
    `;
      setShadowHTML(root, template);
      document.documentElement.appendChild(host);
      this.wire(root, spec);
    }
    wire(root, spec) {
      const video = root.querySelector("video.screamer");
      const soundBtn = root.querySelector('[data-act="unmute"]');
      if (video) {
        video.muted = true;
        void video.play().catch(() => {
        });
      }
      playScreamerSound().catch(() => {
        if (soundBtn) soundBtn.style.display = "block";
      });
      soundBtn?.addEventListener("click", () => {
        void playScreamerSound();
        soundBtn.style.display = "none";
      });
      const breakBtn = root.querySelector('[data-act="break"]');
      breakBtn?.addEventListener("click", () => this.finish("accepted_break"));
      const cont = root.querySelector('[data-act="continue"]');
      if (cont) {
        let remaining = spec.frictionSec;
        if (remaining > 0) {
          const tick = () => {
            remaining -= 1;
            if (remaining <= 0) {
              cont.disabled = false;
              cont.textContent = "Seguir scrolleando";
            } else {
              cont.textContent = `Seguir scrolleando (${remaining})`;
              this.timers.push(window.setTimeout(tick, 1e3));
            }
          };
          this.timers.push(window.setTimeout(tick, 1e3));
        }
        cont.addEventListener("click", () => {
          if (!cont.disabled) this.finish("dismissed");
        });
      }
      const hold = root.querySelector('[data-act="hold"]');
      if (hold) {
        const fill = hold.querySelector(".fill");
        const lbl = hold.querySelector(".lbl");
        const HOLD_MS = 1800;
        let startT = 0;
        let raf = 0;
        const step = () => {
          const pct = Math.min(100, (performance.now() - startT) / HOLD_MS * 100);
          if (fill) fill.style.width = `${pct}%`;
          if (pct >= 100) {
            this.finish("dismissed");
            return;
          }
          raf = requestAnimationFrame(step);
        };
        const startHold = (e) => {
          e.preventDefault();
          startT = performance.now();
          raf = requestAnimationFrame(step);
        };
        const cancelHold = () => {
          cancelAnimationFrame(raf);
          if (fill) fill.style.width = "0%";
          if (lbl) lbl.textContent = "Mant\xE9n presionado para seguir\u2026";
        };
        hold.addEventListener("pointerdown", startHold);
        hold.addEventListener("pointerup", cancelHold);
        hold.addEventListener("pointerleave", cancelHold);
      }
    }
  };
  function escapeHtml(s) {
    return s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  }
  var ttPolicy;
  function getTTPolicy() {
    if (ttPolicy !== void 0) return ttPolicy;
    const tt = window.trustedTypes;
    try {
      ttPolicy = tt ? tt.createPolicy("scroll-infinito", { createHTML: (s) => s }) : null;
    } catch {
      ttPolicy = null;
    }
    return ttPolicy;
  }
  function setShadowHTML(root, html) {
    const policy = getTTPolicy();
    try {
      root.innerHTML = policy ? policy.createHTML(html) : html;
      return;
    } catch {
    }
    try {
      const parsed = new DOMParser().parseFromString(`<div>${html}</div>`, "text/html");
      const wrapper = parsed.body.firstElementChild;
      if (wrapper) {
        while (wrapper.firstChild) root.appendChild(wrapper.firstChild);
      }
    } catch (e) {
      console.log("[SCROLL_INFINITO] no se pudo renderizar el overlay:", e);
    }
  }

  // src/content/soundPrompt.ts
  var HOST_ID2 = "scroll-infinito-sound-prompt";
  function showSoundPrompt() {
    if (isAudioPrimed()) return;
    if (document.getElementById(HOST_ID2)) return;
    const host = document.createElement("div");
    host.id = HOST_ID2;
    host.style.cssText = "all: initial; position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); z-index: 2147483646;";
    const root = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
    .btn {
      font: 600 14px system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
      color: #fff; background: #6c5ce7; border: 0; border-radius: 999px;
      padding: 12px 18px; cursor: pointer; box-shadow: 0 6px 20px rgba(0,0,0,.35);
      display: flex; align-items: center; gap: 8px;
    }
    .btn:hover { filter: brightness(1.08); }
    .x { background: rgba(255,255,255,.25); border-radius: 50%; width: 18px; height: 18px;
         display: inline-flex; align-items: center; justify-content: center; font-size: 12px; }
  `;
    root.appendChild(style);
    const btn = document.createElement("button");
    btn.className = "btn";
    const label = document.createElement("span");
    label.textContent = "\u{1F50A} Activar sonido del screamer";
    const close = document.createElement("span");
    close.className = "x";
    close.textContent = "\u2715";
    btn.append(label, close);
    root.appendChild(btn);
    const remove = () => host.remove();
    close.addEventListener("click", (e) => {
      e.stopPropagation();
      remove();
    });
    btn.addEventListener("click", () => {
      primeNow().then(() => {
        label.textContent = "\u2713 Sonido activado";
        close.style.display = "none";
        setTimeout(remove, 1200);
      }).catch(() => {
        label.textContent = "\u26A0\uFE0F Intenta de nuevo";
      });
    });
    document.documentElement.appendChild(host);
    setTimeout(() => {
      if (!isAudioPrimed()) remove();
    }, 2e4);
  }

  // src/content/index.ts
  console.log("%c[SCROLL_INFINITO]", "color:#6c5ce7;font-weight:bold", "content script inyectado en", location.host, location.pathname);
  async function main() {
    const adapter = getAdapterForHost(location.host);
    if (!adapter) {
      console.log("[SCROLL_INFINITO] host no soportado:", location.host);
      return;
    }
    const config = await getConfig().catch((e) => {
      console.log("[SCROLL_INFINITO] no se pudo leer la config (\xBFservice worker ca\xEDdo?):", e);
      return null;
    });
    if (!config) return;
    if (!config.perSiteEnabled[adapter.id]) {
      console.log("[SCROLL_INFINITO] sitio desactivado en Opciones:", adapter.id);
      return;
    }
    console.log("[SCROLL_INFINITO] activo en", adapter.id, "\xB7 feed actual:", adapter.isFeedPath(location.pathname));
    showSoundPrompt();
    const sensor = new ScrollSensor(200);
    const observer = new FeedObserver(adapter);
    const overlay = new ScreamerOverlay(config);
    const isFeedActive = () => adapter.isFeedPath(location.pathname);
    let todayMinutes = 0;
    const refreshMinutes = () => getTodayMinutes().then((m) => todayMinutes = m).catch(() => {
    });
    void refreshMinutes();
    window.setInterval(refreshMinutes, 6e4);
    const machine = new StateMachine({
      adapter,
      config,
      sensor,
      observer,
      overlay,
      isFeedActive,
      getTodayMinutes: () => todayMinutes
    });
    await machine.start();
    let lastPath = location.pathname;
    const notifyRoute = () => {
      if (location.pathname === lastPath) return;
      lastPath = location.pathname;
      const stillFeed = isFeedActive();
      if (stillFeed) {
        sensor.pump(1);
        observer.bumpItems(1);
      }
      machine.onRouteChange(stillFeed);
    };
    const origPush = history.pushState.bind(history);
    const origReplace = history.replaceState.bind(history);
    history.pushState = function(...args) {
      const r = origPush(...args);
      queueMicrotask(notifyRoute);
      return r;
    };
    history.replaceState = function(...args) {
      const r = origReplace(...args);
      queueMicrotask(notifyRoute);
      return r;
    };
    window.addEventListener("popstate", notifyRoute);
    window.setInterval(notifyRoute, 1e3);
    let hiddenTimer;
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        hiddenTimer = window.setTimeout(() => machine.onHidden(), 5e3);
      } else if (hiddenTimer) {
        clearTimeout(hiddenTimer);
      }
    });
    window.addEventListener("pagehide", () => machine.stop(), { once: true });
    window.addEventListener(
      "keydown",
      (e) => {
        if (e.altKey && e.shiftKey && e.code === "KeyS") {
          e.preventDefault();
          e.stopPropagation();
          void machine.forceInterrupt();
        }
        if (e.altKey && e.shiftKey && e.code === "KeyR") {
          e.preventDefault();
          e.stopPropagation();
          machine.reset();
        }
      },
      { capture: true }
    );
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.kind === "RESET_COUNTER") machine.reset();
      if (msg?.kind === "FORCE_SCREAMER") void machine.forceInterrupt();
    });
    window.__SCROLL_INFINITO = { machine, sensor, observer };
    console.log("[SCROLL_INFINITO] listo \xB7 Alt+Shift+S = disparar screamer \xB7 Alt+Shift+R = reiniciar contador");
  }
  main().catch((e) => console.log("[SCROLL_INFINITO] init error", e));
})();
//# sourceMappingURL=content.js.map
