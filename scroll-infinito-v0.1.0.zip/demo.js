"use strict";
(() => {
  // src/content/overlay/levels.ts
  var BASE = [
    {
      level: 1,
      frictionSec: 0,
      emojiSize: 4,
      emojis: ["\u{1F440}"],
      title: "\xBFSigues ah\xED?",
      subtitlePool: [
        "Llevas ~{screens} pantallas. Respira una vez \u{1FAE7}",
        "Peque\xF1a pausa: \xBFesto te sirve ahora mismo?",
        "Hey, solo un check r\xE1pido \u{1F44B}"
      ],
      showUsageMirror: false,
      holdToContinue: false
    },
    {
      level: 2,
      frictionSec: 3,
      emojiSize: 7,
      emojis: ["\u{1F57A}", "\u{1F483}", "\u{1FAA9}", "\u{1F389}"],
      title: "OK esto ya es mucho scroll",
      subtitlePool: [
        "Tu pulgar entren\xF3 para un marat\xF3n \u{1F3C3}",
        "~{screens} pantallas. El algoritmo est\xE1 feliz, \xBFy t\xFA?",
        "Baile de interrupci\xF3n activado \u{1FAA9}"
      ],
      showUsageMirror: false,
      holdToContinue: false
    },
    {
      level: 3,
      frictionSec: 6,
      emojiSize: 10,
      emojis: ["\u{1F999}", "\u{1F6F8}", "\u{1F921}", "\u{1F438}"],
      title: "\xBFDe verdad quieres esto ahora?",
      subtitlePool: [
        'No "\xBFpuedo seguir?", sino: \xBFde verdad lo quiero? \u{1F914}',
        "Una llama te est\xE1 juzgando con cari\xF1o \u{1F999}",
        "Cierra los ojos 3 segundos. Te esperamos."
      ],
      showUsageMirror: true,
      holdToContinue: false
    },
    {
      level: 4,
      frictionSec: 8,
      emojiSize: 14,
      emojis: ["\u{1F6A8}", "\u{1F920}", "\u{1F996}", "\u{1FAE0}"],
      title: "SCROLL_INFINITO dice: ya estuvo \u{1F920}",
      subtitlePool: [
        "Mira tu d\xEDa. Mant\xE9n presionado si DE VERDAD quieres seguir.",
        "Tu yo de ma\xF1ana te lo va a agradecer \u{1FAE0}",
        "Plan twist: cierra esto y ve por agua \u{1F4A7}"
      ],
      showUsageMirror: true,
      holdToContinue: true
    }
  ];
  var INTENSITY_MULT = {
    suave: 0.5,
    normal: 1,
    intenso: 1.6
  };
  function getLevelSpec(level, intensity) {
    const spec = BASE[Math.max(0, Math.min(BASE.length - 1, level - 1))];
    return { ...spec, frictionSec: Math.round(spec.frictionSec * INTENSITY_MULT[intensity]) };
  }
  function pickSubtitle(spec, screens) {
    const idx = (spec.level + screens) % spec.subtitlePool.length;
    return spec.subtitlePool[idx].replace("{screens}", String(screens));
  }

  // src/content/overlay/a11y.ts
  function prefersReducedMotion() {
    return window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
  }

  // src/content/overlay/audioUnlock.ts
  var audio = null;
  var primed = false;
  function initScreamerAudio(url) {
    if (audio) return;
    audio = new Audio(url);
    audio.loop = true;
    audio.preload = "auto";
    const prime = () => {
      if (!audio || primed) return;
      audio.muted = false;
      audio.volume = 0;
      audio.play().then(() => {
        audio.pause();
        audio.currentTime = 0;
        primed = true;
        console.log("[SCROLL_INFINITO] audio desbloqueado para esta sesi\xF3n \u{1F50A}");
      }).catch(() => {
      });
    };
    ["pointerdown", "keydown", "touchstart"].forEach(
      (ev) => window.addEventListener(ev, prime, { capture: true, once: true })
    );
  }
  function playScreamerSound() {
    if (!audio) return Promise.reject(new Error("audio no inicializado"));
    audio.muted = false;
    audio.volume = 1;
    audio.currentTime = 0;
    return audio.play();
  }
  function stopScreamerSound() {
    if (audio) {
      audio.pause();
      audio.currentTime = 0;
    }
  }

  // src/content/overlay/overlayHost.ts
  var HOST_ID = "scroll-infinito-overlay-host";
  var ScreamerOverlay = class {
    constructor(cfg) {
      this.timers = [];
      this.pausedMedia = [];
      this.cfg = cfg;
      try {
        initScreamerAudio(chrome.runtime.getURL("assets/screamer.mp4"));
      } catch {
      }
    }
    show(opts) {
      this.hide();
      this.pausePageMedia();
      return new Promise((resolve) => {
        this.resolveCurrent = resolve;
        this.render(opts);
      });
    }
    hide() {
      this.clearTimers();
      stopScreamerSound();
      this.host?.remove();
      this.host = void 0;
      this.resolveCurrent = void 0;
      this.resumePageMedia();
    }
    /** Pausa todo video/audio que esté sonando en la página (el Short de fondo). */
    pausePageMedia() {
      this.pausedMedia = [];
      document.querySelectorAll("video, audio").forEach((m) => {
        if (!m.paused && !m.ended) {
          try {
            m.pause();
            this.pausedMedia.push(m);
          } catch {
          }
        }
      });
    }
    /** Reanuda lo que pausamos cuando se cierra el screamer. */
    resumePageMedia() {
      this.pausedMedia.forEach((m) => void m.play().catch(() => {
      }));
      this.pausedMedia = [];
    }
    finish(r) {
      const resolve = this.resolveCurrent;
      this.hide();
      resolve?.(r);
    }
    clearTimers() {
      this.timers.forEach((t) => clearTimeout(t));
      this.timers = [];
    }
    render(opts) {
      const reduced = prefersReducedMotion();
      const spec = getLevelSpec(opts.level, this.cfg.escalationIntensity);
      const subtitle = pickSubtitle(spec, opts.screens);
      const host = document.createElement("div");
      host.id = HOST_ID;
      host.style.cssText = "all: initial; position: fixed; inset: 0; z-index: 2147483647;";
      const root = host.attachShadow({ mode: "open" });
      this.host = host;
      const videoUrl = chrome.runtime.getURL("assets/screamer.mp4");
      const mirror = spec.showUsageMirror && opts.budgetMin ? `<div class="mirror">Hoy: <b>${opts.budgetUsedMin ?? 0} min</b> / meta ${opts.budgetMin} min</div>` : spec.showUsageMirror && opts.budgetUsedMin ? `<div class="mirror">Hoy llevas <b>${opts.budgetUsedMin} min</b> de scroll</div>` : "";
      const videoMax = 220 + opts.level * 60;
      const template = `
      <style>
        :host { all: initial; }
        .backdrop {
          position: fixed; inset: 0;
          display: flex; align-items: center; justify-content: center;
          background: rgba(8, 10, 20, ${0.55 + opts.level * 0.1});
          backdrop-filter: blur(${2 + opts.level * 2}px);
          font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
          color: #fff; text-align: center; padding: 24px;
          ${reduced ? "" : "animation: si-fade 0.25s ease-out;"}
        }
        .card {
          max-width: 520px; width: 100%;
          background: linear-gradient(160deg, #1b2240, #2a1f4d);
          border: 2px solid #6c5ce7; border-radius: 22px;
          padding: 28px 26px 22px; box-shadow: 0 20px 60px rgba(0,0,0,.5);
        }
        .video-wrap { position: relative; display:flex; justify-content:center; }
        video.screamer {
          width: 100%; max-width: ${videoMax}px; border-radius: 16px;
          background: #000; box-shadow: 0 10px 30px rgba(0,0,0,.5);
        }
        .sound-btn {
          position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%);
          background: #e17055; color: #fff; font-weight: 700; font-size: .9rem;
          border: 0; border-radius: 999px; padding: 8px 16px; cursor: pointer;
          box-shadow: 0 4px 14px rgba(0,0,0,.4); animation: si-pulse 1.2s ease-in-out infinite;
        }
        @keyframes si-pulse { 0%,100% { transform: translateX(-50%) scale(1) } 50% { transform: translateX(-50%) scale(1.07) } }
        h1 { font-size: 1.55rem; margin: 14px 0 6px; }
        p.sub { font-size: 1.05rem; opacity: .9; margin: 0 0 14px; }
        .mirror { font-size: .95rem; background: rgba(255,255,255,.08); border-radius: 10px; padding: 8px 12px; margin: 0 0 16px; }
        .btns { display: flex; flex-direction: column; gap: 10px; }
        button { font: inherit; font-size: 1rem; padding: 13px 16px; border-radius: 12px; border: 0; cursor: pointer; }
        .primary { background: #00b894; color: #04241c; font-weight: 700; }
        .primary:hover { filter: brightness(1.08); }
        .secondary { background: rgba(255,255,255,.1); color: #fff; }
        .secondary[disabled] { opacity: .45; cursor: not-allowed; }
        .hold { background: rgba(255,255,255,.1); color:#fff; position:relative; overflow:hidden; }
        .hold .fill { position:absolute; inset:0; background:#e17055; width:0%; }
        .hold span { position: relative; z-index: 1; }
        .foot { margin-top: 12px; font-size: .8rem; opacity: .6; }
        @keyframes si-bounce { from { transform: translateY(0) } to { transform: translateY(-18px) } }
        @keyframes si-spin { to { transform: rotate(360deg) } }
        @keyframes si-fade { from { opacity: 0 } to { opacity: 1 } }
      </style>
      <div class="backdrop" role="dialog" aria-modal="true" aria-label="Pausa de scroll">
        <div class="card">
          <div class="video-wrap">
            <video class="screamer" src="${videoUrl}" loop playsinline></video>
            <button class="sound-btn" data-act="unmute" style="display:none">\u{1F50A} toca para sonido</button>
          </div>
          <h1>${spec.title}</h1>
          <p class="sub">${escapeHtml(subtitle)}</p>
          ${mirror}
          <div class="btns">
            <button class="primary" data-act="break">\u270B Ya termin\xE9 / tomar pausa</button>
            ${spec.holdToContinue ? `<button class="hold" data-act="hold"><span class="lbl">Mant\xE9n presionado para seguir\u2026</span><div class="fill"></div></button>` : `<button class="secondary" data-act="continue" ${spec.frictionSec > 0 ? "disabled" : ""}>Seguir scrolleando${spec.frictionSec > 0 ? ` (${spec.frictionSec})` : ""}</button>`}
          </div>
          <div class="foot">SCROLL_INFINITO \xB7 nivel ${opts.level}</div>
        </div>
      </div>
    `;
      setShadowHTML(root, template);
      document.documentElement.appendChild(host);
      this.wire(root, spec);
    }
    wire(root, spec) {
      const video = root.querySelector("video.screamer");
      const soundBtn = root.querySelector('[data-act="unmute"]');
      if (video) {
        video.muted = true;
        void video.play().catch(() => {
        });
      }
      playScreamerSound().catch(() => {
        if (soundBtn) soundBtn.style.display = "block";
      });
      soundBtn?.addEventListener("click", () => {
        void playScreamerSound();
        soundBtn.style.display = "none";
      });
      const breakBtn = root.querySelector('[data-act="break"]');
      breakBtn?.addEventListener("click", () => this.finish("accepted_break"));
      const cont = root.querySelector('[data-act="continue"]');
      if (cont) {
        let remaining = spec.frictionSec;
        if (remaining > 0) {
          const tick = () => {
            remaining -= 1;
            if (remaining <= 0) {
              cont.disabled = false;
              cont.textContent = "Seguir scrolleando";
            } else {
              cont.textContent = `Seguir scrolleando (${remaining})`;
              this.timers.push(window.setTimeout(tick, 1e3));
            }
          };
          this.timers.push(window.setTimeout(tick, 1e3));
        }
        cont.addEventListener("click", () => {
          if (!cont.disabled) this.finish("dismissed");
        });
      }
      const hold = root.querySelector('[data-act="hold"]');
      if (hold) {
        const fill = hold.querySelector(".fill");
        const lbl = hold.querySelector(".lbl");
        const HOLD_MS = 1800;
        let startT = 0;
        let raf = 0;
        const step = () => {
          const pct = Math.min(100, (performance.now() - startT) / HOLD_MS * 100);
          if (fill) fill.style.width = `${pct}%`;
          if (pct >= 100) {
            this.finish("dismissed");
            return;
          }
          raf = requestAnimationFrame(step);
        };
        const startHold = (e) => {
          e.preventDefault();
          startT = performance.now();
          raf = requestAnimationFrame(step);
        };
        const cancelHold = () => {
          cancelAnimationFrame(raf);
          if (fill) fill.style.width = "0%";
          if (lbl) lbl.textContent = "Mant\xE9n presionado para seguir\u2026";
        };
        hold.addEventListener("pointerdown", startHold);
        hold.addEventListener("pointerup", cancelHold);
        hold.addEventListener("pointerleave", cancelHold);
      }
    }
  };
  function escapeHtml(s) {
    return s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  }
  var ttPolicy;
  function getTTPolicy() {
    if (ttPolicy !== void 0) return ttPolicy;
    const tt = window.trustedTypes;
    try {
      ttPolicy = tt ? tt.createPolicy("scroll-infinito", { createHTML: (s) => s }) : null;
    } catch {
      ttPolicy = null;
    }
    return ttPolicy;
  }
  function setShadowHTML(root, html) {
    const policy = getTTPolicy();
    try {
      root.innerHTML = policy ? policy.createHTML(html) : html;
      return;
    } catch {
    }
    try {
      const parsed = new DOMParser().parseFromString(`<div>${html}</div>`, "text/html");
      const wrapper = parsed.body.firstElementChild;
      if (wrapper) {
        while (wrapper.firstChild) root.appendChild(wrapper.firstChild);
      }
    } catch (e) {
      console.log("[SCROLL_INFINITO] no se pudo renderizar el overlay:", e);
    }
  }

  // src/data/schema.ts
  var DEFAULT_CONFIG = {
    cooldownMinutes: 20,
    retriggerEveryNScrolls: 30,
    doomThreshold: 0.6,
    minItemsForTrigger: 15,
    escalationIntensity: "normal",
    dailyBudgetMinutes: 60,
    weeklyBudgetMinutes: 0,
    perSiteEnabled: {
      instagram: true,
      tiktok: true,
      twitter: true,
      reddit: true,
      youtube: true,
      facebook: true
    },
    ifThenPlan: "",
    soundEnabled: true,
    aiEnabled: false,
    proxyUrl: ""
  };
  function clampCooldown(min) {
    return Math.max(15, Math.min(30, Math.round(min)));
  }
  var STORAGE_KEYS = {
    config: "si_config",
    cooldownPrefix: "si_cooldown_",
    digestCache: "si_digest_cache"
  };

  // src/background/storage.ts
  async function getConfig() {
    const raw = await chrome.storage.local.get(STORAGE_KEYS.config);
    const stored = raw[STORAGE_KEYS.config] ?? {};
    return {
      ...DEFAULT_CONFIG,
      ...stored,
      perSiteEnabled: { ...DEFAULT_CONFIG.perSiteEnabled, ...stored.perSiteEnabled ?? {} },
      cooldownMinutes: clampCooldown(stored.cooldownMinutes ?? DEFAULT_CONFIG.cooldownMinutes)
    };
  }

  // src/ui/demo.ts
  function el(sel) {
    const e = document.querySelector(sel);
    if (!e) throw new Error(`${sel} no existe`);
    return e;
  }
  async function init() {
    const config = await getConfig().catch(() => DEFAULT_CONFIG);
    const overlay = new ScreamerOverlay(config);
    const sound = el("#sound");
    const status = el("#status");
    document.querySelectorAll("button[data-level]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const level = Number(btn.dataset.level);
        status.textContent = `Mostrando nivel ${level}\u2026`;
        const response = await overlay.show({
          level,
          screens: 42,
          budgetUsedMin: 73,
          budgetMin: config.dailyBudgetMinutes || 60,
          soundEnabled: sound.checked
        });
        status.textContent = `Respuesta del usuario: "${response}"`;
      });
    });
  }
  void init();
})();
//# sourceMappingURL=demo.js.map
